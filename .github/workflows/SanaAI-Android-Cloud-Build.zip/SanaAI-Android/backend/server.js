import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { GoogleAuth } from 'google-auth-library';

const app = express();
app.use(express.json({ limit: '256kb' }));
const origins = (process.env.ALLOWED_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean);
app.use(cors({ origin(origin, cb) { if (!origin || origin === 'null' || origins.length === 0 || origins.includes(origin)) return cb(null, true); cb(new Error('Origin not allowed')); } }));

const SYSTEM = 'أنت سنا، مساعد عربي واضح ومفيد. أجب بلغة المستخدم، وكن دقيقًا ومختصرًا واشرح بخطوات عند الحاجة.';
const timeout = Number(process.env.PROVIDER_TIMEOUT_MS || 45000);
async function requestJson(url, options) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(url, { ...options, signal: controller.signal });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data?.error?.message || data?.error || data?.message || `HTTP ${response.status}`);
    return data;
  } finally { clearTimeout(timer); }
}

async function openaiChat(message, system = SYSTEM) {
  const data = await requestJson(process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1/chat/completions', {
    method: 'POST', headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: process.env.OPENAI_MODEL || 'gpt-4o-mini', messages: [{ role: 'system', content: system }, { role: 'user', content: message }], temperature: 0.6, max_tokens: 900 })
  });
  return data?.choices?.[0]?.message?.content || '';
}
async function geminiChat(message) {
  const model = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
  const data = await requestJson(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(process.env.GEMINI_API_KEY)}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ systemInstruction: { parts: [{ text: SYSTEM }] }, contents: [{ role: 'user', parts: [{ text: message }] }], generationConfig: { temperature: 0.6, maxOutputTokens: 900 } })
  });
  return (data?.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('');
}
async function claudeChat(message) {
  const model = process.env.CLAUDE_MODEL || 'claude-3-5-haiku-latest';
  const data = await requestJson('https://api.anthropic.com/v1/messages', {
    method: 'POST', headers: { 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({ model, max_tokens: 900, system: SYSTEM, messages: [{ role: 'user', content: message }] })
  });
  return (data?.content || []).filter(x => x.type === 'text').map(x => x.text).join('\n');
}
async function vertexChat(message, system = SYSTEM) {
  const base = (process.env.VERTEX_BASE_URL || '').replace(/\/$/, '');
  if (!base) throw new Error('VERTEX_BASE_URL غير مضبوط');
  const auth = new GoogleAuth({ scopes: ['https://www.googleapis.com/auth/cloud-platform'] });
  const client = await auth.getClient();
  const token = await client.getAccessToken();
  if (!token?.token) throw new Error('تعذر الحصول على صلاحية Google Cloud');
  const data = await requestJson(`${base}/chat/completions`, {
    method: 'POST', headers: { Authorization: `Bearer ${token.token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: process.env.VERTEX_MODEL || 'default', messages: [{ role: 'system', content: system }, { role: 'user', content: message }], temperature: 0.6, max_tokens: 900 })
  });
  return data?.choices?.[0]?.message?.content || '';
}

const providers = [
  { id: 'chatgpt', name: 'ChatGPT', configured: () => Boolean(process.env.OPENAI_API_KEY), run: m => openaiChat(m) },
  { id: 'gemini', name: 'Gemini', configured: () => Boolean(process.env.GEMINI_API_KEY), run: m => geminiChat(m) },
  { id: 'claude', name: 'Claude', configured: () => Boolean(process.env.ANTHROPIC_API_KEY), run: m => claudeChat(m) },
  { id: 'vertex', name: 'Google Cloud', configured: () => Boolean(process.env.VERTEX_BASE_URL), run: m => vertexChat(m) }
];
app.get('/health', (_req, res) => res.json({ ok: true, providers: providers.filter(p => p.configured()).map(p => p.id) }));
app.post('/api/chat', async (req, res) => {
  const message = String(req.body?.message || '').trim();
  if (!message || message.length > 12000) return res.status(400).json({ error: 'الرسالة فارغة أو طويلة جدًا.' });
  const active = providers.filter(p => p.configured());
  if (!active.length) return res.status(503).json({ error: 'لم يتم إعداد أي نموذج بعد. أضف مفاتيح النماذج في متغيرات البيئة الآمنة على الخادم.' });
  const settled = await Promise.all(active.map(async p => {
    try {
      const reply = await p.run(message);
      if (!reply) throw new Error('لم يرجع النموذج نصًا.');
      return { id: p.id, name: p.name, ok: true, reply: typeof reply === 'string' ? reply : JSON.stringify(reply) };
    } catch (e) { return { id: p.id, name: p.name, ok: false, error: String(e.message || 'فشل الاتصال').slice(0, 350) }; }
  }));
  const successful = settled.filter(x => x.ok);
  let summary = '';
  if (successful.length > 1) {
    const notes = successful.map(x => `### ${x.name}\n${x.reply}`).join('\n\n');
    const synthesisPrompt = `مهمة المستخدم:\n${message}\n\nإجابات النماذج:\n${notes}\n\nاكتب خلاصة عربية واحدة متوازنة. اجمع النقاط المتفق عليها، ووضح الاختلافات المهمة، ولا تخترع معلومات.`;
    const coordinator = process.env.ORCHESTRATOR_PROVIDER || (process.env.OPENAI_API_KEY ? 'chatgpt' : process.env.VERTEX_BASE_URL ? 'vertex' : process.env.GEMINI_API_KEY ? 'gemini' : 'claude');
    try {
      if (coordinator === 'chatgpt' && process.env.OPENAI_API_KEY) summary = await openaiChat(synthesisPrompt, 'أنت منسق فريق سنا. ادمج آراء النماذج في إجابة عربية دقيقة.');
      else if (coordinator === 'vertex' && process.env.VERTEX_BASE_URL) summary = await vertexChat(synthesisPrompt, 'أنت منسق فريق سنا. ادمج آراء النماذج في إجابة عربية دقيقة.');
      else if (coordinator === 'gemini' && process.env.GEMINI_API_KEY) summary = await geminiChat(synthesisPrompt);
      else if (coordinator === 'claude' && process.env.ANTHROPIC_API_KEY) summary = await claudeChat(synthesisPrompt);
    } catch (e) { console.warn('Synthesis failed:', e.message); }
  }
  if (!successful.length) return res.status(502).json({ error: 'تعذر الحصول على إجابة من النماذج المضبوطة.', results: settled });
  res.json({ results: settled, summary: summary || (successful.length === 1 ? successful[0].reply : ''), model: successful.map(x => x.name).join(' + ') });
});
const port = Number(process.env.PORT || 8080);
app.listen(port, '0.0.0.0', () => console.log(`Sana multi-model API listening on ${port}`));
