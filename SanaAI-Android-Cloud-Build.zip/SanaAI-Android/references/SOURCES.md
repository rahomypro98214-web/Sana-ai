# References supplied for Sana AI

- Google Cloud Vertex AI notebooks: Model Garden SDK deployment, custom model import, Terraform deployment, MaaS reasoning, Qwen3 ADK, and EAGLE benchmarking.
- awesome-agent-apis: catalog of agent APIs and capabilities.
- runonweb.ai: browser-side AI modules using WebGPU/WASM; modules require deliberate integration.
- free-ai-models: frequently updated catalog of free model APIs and providers; free-tier status can change.
- awesome-coding-plan: provider plans/pricing reference; prices and eligibility can change.
- awesome-free-byok-models: BYOK provider catalog; users may need their own credentials.
