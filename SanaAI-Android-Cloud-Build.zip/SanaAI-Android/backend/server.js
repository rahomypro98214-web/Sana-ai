import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { GoogleAuth } from 'google-auth-library';

const app = express();
app.use(express.json({ limit: '256kb' }));
const origins = (process.env.ALLOWED_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean);
app.use(cors({ origin(origin, cb) { if (!origin || origin === 'null' || origins.length === 0 || origins.includes(origin)) return cb(null, true); cb(new Error('Origin not allowed')); } }));

app.get('/health', (_req, res) => res.json({ ok: true, configured: Boolean(process.env.VERTEX_BASE_URL) }));
app.post('/api/chat', async (req, res) => {
  try {
    const message = String(req.body?.message || '').trim();
    if (!message || message.length > 12000) return res.status(400).json({ error: 'الرسالة فارغة أو طويلة جدًا.' });
    const base = (process.env.VERTEX_BASE_URL || '').replace(/\/$/, '');
    if (!base) return res.status(503).json({ error: 'لم يتم ضبط VERTEX_BASE_URL على الخادم بعد.' });
    const auth = new GoogleAuth({ scopes: ['https://www.googleapis.com/auth/cloud-platform'] });
    const client = await auth.getClient();
    const token = await client.getAccessToken();
    if (!token?.token) throw new Error('تعذر الحصول على صلاحية Google Cloud من حساب الخدمة.');
    const response = await fetch(`${base}/chat/completions`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token.token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: process.env.VERTEX_MODEL || 'default', messages: [
        { role: 'system', content: 'أنت سنا، مساعد عربي واضح ومفيد. أجب بلغة المستخدم، واشرح بخطوات عند الحاجة.' },
        { role: 'user', content: message }
      ], temperature: 0.7, max_tokens: 900 })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) return res.status(response.status).json({ error: data?.error?.message || data?.message || `Vertex AI returned ${response.status}` });
    const reply = data?.choices?.[0]?.message?.content;
    if (!reply) return res.status(502).json({ error: 'لم يرجع النموذج نصًا مفهومًا.' });
    res.json({ reply: typeof reply === 'string' ? reply : JSON.stringify(reply), model: data.model || process.env.VERTEX_MODEL || 'Vertex AI' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'حدث خطأ أثناء الاتصال بنموذج Google Cloud.' });
  }
});
const port = Number(process.env.PORT || 8080);
app.listen(port, '0.0.0.0', () => console.log(`Sana API listening on ${port}`));
